package jac.fsd02.foodorder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodorderApplicationTests {

	@Test
	void contextLoads() {
	}

}
