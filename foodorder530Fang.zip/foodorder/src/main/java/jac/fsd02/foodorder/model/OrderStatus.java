package jac.fsd02.foodorder.model;

public enum OrderStatus {
    UNPAID,
    PAID,
    DELIVERING,
    DELIVERED
}
