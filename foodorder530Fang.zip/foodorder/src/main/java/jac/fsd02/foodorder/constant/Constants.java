package jac.fsd02.foodorder.constant;

public class Constants {

    public static double TAX_RATE = 0.15;
}
