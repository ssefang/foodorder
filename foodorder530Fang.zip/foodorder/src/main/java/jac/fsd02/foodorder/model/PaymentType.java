package jac.fsd02.foodorder.model;

public enum PaymentType {
    CASH,
    DEBIT,
    CREDIT
}
