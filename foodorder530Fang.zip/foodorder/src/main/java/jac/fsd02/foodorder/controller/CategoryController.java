package jac.fsd02.foodorder.controller;

import org.springframework.ui.Model;

public interface CategoryController {

    String getCategoryList(Model model);
}
