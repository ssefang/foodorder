package jac.fsd02.foodorder.constant;

public class ErrorMessage {
    public static final String NAME_IS_REQUIRED_ERROR_MESSAGE = "please provide name";
    public static final String NAME_SIZE_ERROR_MESSAGE = "The name needs to be at least 2 character";
    public static final String NUMBER_IS_REQUIRED_ERROR_MESSAGE = "please provide Number";
    public static final String CAR_MODEL_IS_REQUIRED_ERROR_MESSAGE = "please provide CarModel";
}
