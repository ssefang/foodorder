package jac.fsd02.foodorder.model;

public enum UserType {
    USER,
    ADMIN
}
